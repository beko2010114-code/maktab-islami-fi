#!/usr/bin/env python3
"""Fail the build if the required Quran/tafsir datasets are absent or incomplete."""
from pathlib import Path
import json, sys

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'app' / 'src' / 'main' / 'assets' / 'data'

errors=[]
qpath=DATA/'quran.json'
if not qpath.exists() or qpath.stat().st_size < 100_000:
    errors.append(f'Quran dataset missing or suspiciously small: {qpath}')
else:
    try:
        q=json.loads(qpath.read_text(encoding='utf-8'))
        if not isinstance(q,list) or len(q)!=114:
            errors.append(f'Quran must contain 114 surahs; found {len(q) if isinstance(q,list) else type(q).__name__}')
        total=sum(len(x.get('verses',[])) for x in q if isinstance(x,dict))
        if total != 6236:
            errors.append(f'Quran must contain 6236 verses; found {total}')
    except Exception as e:
        errors.append(f'Cannot parse Quran dataset: {e}')

for filename, title in [('tafsir_muyassar.json','التفسير الميسر'),('tafsir_saadi.json','تفسير السعدي')]:
    p=DATA/filename
    if not p.exists() or p.stat().st_size < 100_000:
        errors.append(f'{title} missing or suspiciously small: {p}')
        continue
    try:
        obj=json.loads(p.read_text(encoding='utf-8'))
        surahs=obj.get('surahs',{})
        if not isinstance(surahs,dict) or len(surahs)!=114:
            errors.append(f'{title} must contain 114 surahs; found {len(surahs) if isinstance(surahs,dict) else type(surahs).__name__}')
        missing=[str(i) for i in range(1,115) if str(i) not in surahs]
        if missing:
            errors.append(f'{title} missing surahs: {", ".join(missing[:10])}')
    except Exception as e:
        errors.append(f'Cannot parse {filename}: {e}')

if errors:
    print('DATA VALIDATION FAILED')
    for e in errors: print('ERROR:',e)
    sys.exit(1)

for p in sorted(DATA.glob('*')):
    print(f'{p.name}: {p.stat().st_size:,} bytes')
print('DATA VALIDATION PASSED: Quran 114 surahs / 6236 verses + both tafsir datasets present.')
